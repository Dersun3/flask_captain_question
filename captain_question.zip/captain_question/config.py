# 数据库的配置变量
HOSTNAME ='127.0.0.1'
PORT =3306
DATABASE='flask'
USERNAME ='root'
PASSWORD='root'
DB_URI='mysql+pymysql://{}:{}@{}:{}/{}?charset=utf8'.format(USERNAME,PASSWORD,HOSTNAME,PORT,DATABASE)
SQLALCHEMY_DATABASE_URI = DB_URI
#设置这一项是每次请求结束后都会自动提交数据库中的变动
SQLALCHEMY_TRACK_MODIFICATIONS = True  # 忽视该警告
SECRET_KEY = "263gksdbk293209490"

# 邮箱配置
# 使用qq邮箱
# vtmgcehifzczcfha

MAIL_SERVER = "smtp.qq.com"
MAIL_PORT = 465
MAIL_USE_TLS = False
MAIL_USE_SSL = True
MAIL_DEBUG = True
MAIL_USERNAME = "2067266431@qq.com"
MAIL_PASSWORD = "vtmgcehifzczcfha"
MAIL_DEFAULT_SENDER  = "2067266431@qq.com"
