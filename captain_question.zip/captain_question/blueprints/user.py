from flask import Blueprint,render_template,request,redirect,url_for,jsonify,session,flash
from exts import mail,db
from flask_mail import Message
from models import EmailCaptchaModel,UserModel
import string
import random
from datetime import datetime
from .forms import RegisterForm,LoginForm
from werkzeug.security import generate_password_hash,check_password_hash


bp = Blueprint("user",__name__,url_prefix="/user")


@bp.route("/login",methods=['GET','POST'])
def login():
    if request.method == "GET":
        return render_template("login.html")
    else:
        form = LoginForm(request.form)
        if form.validate():
            email = form.email.data
            password = form.password.data
            user = UserModel.query.filter_by(email=email).first()
            if user and check_password_hash(user.password,password):
                session['user_id'] = user.id  # session记录用户id
                return redirect("/")
            else:
                flash("邮箱和密码不匹配！")
                return redirect(url_for("user.login"))
        else:
            flash("邮箱或密码格式错误！")
            return redirect(url_for("user.login"))

@bp.route("/register",methods=["GET","POST"])
def register():
    return render_template("register.html")


@bp.route("/logout")
def logout():
    # 清除session中的所有数据,并跳转到登录页面
    session.clear()
    return redirect(url_for('user.login'))

# 邮箱
@bp.route("/captcha",methods=["POST"])
def get_captcha():
    # GET/POST
    email = request.form.get("email")
    # 生成随机的验证码
    letters = string.ascii_letters + string.digits  # 字母与数字混合
    captcha = "".join(random.sample(letters,4))  # 生成4个混合的验证码
    try:
        if email:
            message = Message(
                subject="邮箱测试！",
                recipients=[email],
                body=f'【船长问答】您的注册验证码是:{captcha},请不要告诉任何人哦！'
            )
            mail.send(message)
            # 将邮箱存入到数据库中
            captcha_model = EmailCaptchaModel.query.filter_by(email=email).first()
            try:
                if captcha_model:  # 判断邮箱是否已经存在数据库里面
                    captcha_model.captcha = captcha
                    captcha_model.create_time = datetime.now()  # 记录把邮箱录入数据库的时间
                    db.session.commit()
                else:
                    captcha_model = EmailCaptchaModel(email=email,captcha=captcha)
                    db.session.add(captcha_model)
                    db.session.commit()

            except Exception as e:
                print(e)
            print("captcha:", captcha)
            # code:200 表示成功的，正常的请求
            return jsonify({"code":200,})
        else:
            return jsonify({"code":400,"message":"清先传递邮箱！"})
    except Exception as e:
        print(e)